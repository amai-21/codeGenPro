// testScanner.h
#ifndef TESTSCANNER_H
#define TESTSCANNER_H

#include <iostream>
using namespace std;

void testScanner(istream &fileForScanner);

#endif
