// token.cpp
#include "token.h"

// Define tokenNames here to avoid multiple inclusion
string tokenNames[] = {"t1Tk", "t2Tk", "t3Tk", "EOFTk"};
