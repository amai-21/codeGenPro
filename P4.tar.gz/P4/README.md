/* Author Andy Mai; Professor: Dr. Sharlee Climer; Program Translation Project; University of Missouri St. Louis */

This project is known as P4 as part of a course called Program Translation Project under the brilliant professorship of Dr. Sharlee Climer
at the University of Missouri - St. Louis. 

To begin, please do the following:
	1.) enter 'make' in the command line.
	2.) Type './virtMach' in the command line and type P4TestFile1.asm or P4TestFile2.asm.
	3.) Witness the almighty prowess of the assembly code generator made by the great and wonderful Andy Mai!!!
	4.) Have a wonderful summer and hope to see you soon! :)
