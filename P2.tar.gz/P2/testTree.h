// testTree.h
#ifndef TESTREE_H
#define TESTTREE_H
#include "node.h"
#include <string>

void testTreePrint(node_t* rootNode, string::size_type treeLevel);

#endif
