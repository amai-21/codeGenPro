/* Author Andy Mai; Professor: Dr. Sharlee Climer; Program Translation Project; University of Missouri St. Louis */

This project is known as P3 as part of a course called Program Translation Project under the brilliant professorship of Dr. Sharlee Climer
at the University of Missouri - St. Louis. 

To begin, please do the following:
	1.) enter 'make' in the command line.
	2.) Type './P3' in the command line and enter a file into the command line. There are three default files in here right now. Cat them out and use whichever one you like best!
	3.) Witness the almighty prowess of the Static Semantics Checker made my the great and wonderful Andy Mai!!!
	4.) Have another wonderful - and hopefully not a stormy or rainy - day!! :)
